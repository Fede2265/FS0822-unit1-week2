package esercizio;

public enum Categoria {
	BOOKS,
	BABY,
	BOYS
}
