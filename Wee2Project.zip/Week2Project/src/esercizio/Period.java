package esercizio;

public enum Period {
	SETTIMANALE,
	MENSILE,
	SEMESTRALE
}
