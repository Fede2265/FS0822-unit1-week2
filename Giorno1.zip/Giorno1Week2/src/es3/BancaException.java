package es3;

public class BancaException extends Exception {

	public BancaException(String message) {

		System.out.println(message);
	}

	public void printStackTrace() {
		// TODO Auto-generated method stub
		
	}

}