package es3;

import java.util.HashMap;
import java.util.Scanner;

public class PhoneBookManager {
    private HashMap<String, String> phoneBook;

    public PhoneBookManager() {
        phoneBook = new HashMap<>();
    }

    public void addContact() {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter name: ");
			String name = scanner.nextLine();
			scanner.nextLine();

			System.out.println("Enter phone number: ");
			String phoneNumber = scanner.nextLine();
			scanner.nextLine();

			phoneBook.put(name, phoneNumber);
		}

        System.out.println("Contact added successfully.");
    }

    public void deleteContact() {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter name to delete: ");
			String name = scanner.nextLine();

			if (phoneBook.containsKey(name)) {
			    phoneBook.remove(name);
			    System.out.println("Contact deleted successfully.");
			} else {
			    System.out.println("Contact not found.");
			}
		}
    }

    public void searchByName() {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter name to search: ");
			String name = scanner.nextLine();

			if (phoneBook.containsKey(name)) {
			    System.out.println("Phone number of " + name + ": " + phoneBook.get(name));
			} else {
			    System.out.println("Contact not found.");
			}
		}
    }

    public void searchByPhoneNumber() {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Enter phone number to search: ");
			String phoneNumber = scanner.nextLine();

			if (phoneBook.containsValue(phoneNumber)) {
			    for (String name : phoneBook.keySet()) {
			        if (phoneBook.get(name).equals(phoneNumber)) {
			            System.out.println("Name of phone number " + phoneNumber + ": " + name);
			        }
			    }
			} else {
			    System.out.println("Contact not found.");
			}
		}
    }

    public void printContacts() {
        for (String name : phoneBook.keySet()) {
            System.out.println("Name: " + name + " Phone Number: " + phoneBook.get(name));
        }
    }
}