package es3;

import java.util.Scanner;

public class PhoneBookDemo {
    public static void main(String[] args) {
        PhoneBookManager phoneBookManager = new PhoneBookManager();
        try (Scanner scanner = new Scanner(System.in)) {
			int choice = 0;

			while (choice != 6) {
			    System.out.println("\nPhone Book Menu");
			    System.out.println("1. Add Contact");
			    System.out.println("2. Delete Contact");
			    System.out.println("3. Search by Name");
			    System.out.println("4. Search by Phone Number");
			    System.out.println("5. Print Contacts");
			    System.out.println("6. Exit");

			    System.out.print("Enter your choice: ");
			    choice = scanner.nextInt();
			    

			    switch (choice) {
			        case 1:
			            phoneBookManager.addContact();
			            break;
			        case 2:
			            phoneBookManager.deleteContact();
			            break;
			        case 3:
			            phoneBookManager.searchByName();
			            break;
			        case 4:
			            phoneBookManager.searchByPhoneNumber();
			            break;
			        case 5:
			            phoneBookManager.printContacts();
			            break;
			        case 6:
			            System.out.println("Exiting Phone Book.");
			            break;
			        default:
			            System.out.println("Invalid choice.");
			    }
			}
		}
    }
}