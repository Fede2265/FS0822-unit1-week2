package es1;



import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class es1 {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("Enter the number of items to insert: ");
			int n = scanner.nextInt();
			scanner.nextLine();

			Set<String> words = new HashSet<>();
			Set<String> duplicates = new HashSet<>();
			
			for (int i = 0; i < n; i++) {
			    System.out.print("Enter word " + (i + 1) + ": ");
			    String word = scanner.nextLine();
			    if (!words.add(word)) {
			        duplicates.add(word);
			    }
			}
			
			System.out.println("Duplicate words: " + duplicates);
			System.out.println("Number of distinct words: " + words.size());
		}
    }
}







