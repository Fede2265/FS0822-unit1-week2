package es2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class es2 {
    public static void main(String[] args) {
    	try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("Enter the number of items to insert: ");
			int n = scanner.nextInt();
			scanner.nextLine();
			List<Integer> randomList = generateRandomList(n);
			System.out.println("Random list: " + randomList);
			
			List<Integer> reversedList = reverseList(randomList);
			System.out.println("Reversed list: " + reversedList);
		}
    }

    public static List<Integer> generateRandomList(int n) {
        List<Integer> randomList = new ArrayList<>();
        Random rand = new Random();
        
        for (int i = 0; i < n; i++) {
            int randNum = rand.nextInt(101);
            randomList.add(randNum);
        }
        
        Collections.sort(randomList);
        return randomList;
    }

    public static List<Integer> reverseList(List<Integer> list) {
        List<Integer> reversedList = new ArrayList<>(list);
        Collections.reverse(reversedList);
        reversedList.addAll(list);
        return reversedList;
    }

    public static void printListPositions(List<Integer> list, boolean printEvenPositions) {
        for (int i = 0; i < list.size(); i++) {
            if (printEvenPositions) {
                if (i % 2 == 0) {
                    System.out.println("Value at even position " + i + ": " + list.get(i));
                }
            } else {
                if (i % 2 != 0) {
                    System.out.println("Value at odd position " + i + ": " + list.get(i));
                }
            }
        }
    }
}